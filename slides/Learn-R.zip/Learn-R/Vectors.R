################
#
# * VECTORS:
#     A vector is a sequence of items of the SAME basic data type.
        c(1,3,4.5)   # Collect three values in a vector.
        c("a","ab")  # Collect two strings in a vector.
        c(T,F,T)     # Collect three logical values in a vector.
        c(2.1,T)     # Not an error.  Coercion of T to 1.
        c(2,"a",T)   # Not an error.  Coercion of 1 and T to strings.
#     If the items are not of the same type, they are coerced:
#       string <-- numeric <-- logical
#     (If the items are of variable types and should not be coerced,
#      use lists instead of vectors.  See below.)
#
#---
#
# * INDEXING AND SUBSELECTING VECTORS:
#
#   - Numeric indexes: ONE-based
        a <- c(1,3,5)
        a[1]; a[2]; a[3]
#     (This is unlike Python and C which use ZERO-based indexing.)
#   - Vector indexes:
        a[c(1,3)]
#   - Vector expansion: amounts to mapping the indexes, using 'a' as a map.
        a[c(1,2,1,2,1,1,1,3,3,3)]
#   - Exclusions with negative numeric indexes:
        a[-1]
        a[c(-1,-3)]
        a[c(-1,-2,-3)]   # Nothing left.
#   - Logical selection: 
        a[c(T,F,T)]
        a[c(T,T)]        # Cyclic repetition of 'c(T,T)'
        a>2; a[a>2]      # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        b <- c(T,F,T);  a[b]
#     Caution: If the index vector is not of equal length,
#     it will be cyclically repeated:
        a[F]             # c(F,F,F)   'F' is repeated 3 times
        a[T]             # c(T,T,T)
        a[c(T,F)]        # c(T,F,T)   
        a[c(T,T,F,F,F)]  # If too long, the index vector is truncated.
        (1:12)[c(T,T,F)] # Leave out every third item.
#   - Vectors can be indexed repeatedly, following the functional paradigm:
        a[c(1,3)][2]     # Select item two of a[c(1,3)], i.e. item 3 of 'a'.
#       (Looks like a matrix element in C, but isn't!!)
        (a[c(1,3)])[2]   # This is what it really means.  
#       Think of a[c(1,3)] as the result of some selection function.
        a[c(1,3)][c(1,2,1,2)]
#   - Vector indexing and subsetting can be used for assignment:
        a[1:2] <- c(10,20)
        a
        a[c(1,3)] <- c(100,200)
        a
        a[-2] <- c(1000,2000)
        a  
        a[c(F,T,T)] <- c(10000,20000)
        a
        a[2:3] <- 0        # "0" is repeated to fill both vector elements.
        b <- 1:10
        b
        b[3:6] <- c(10,20) # "c(10,20)" is cyclically repeated.
        b
        b[3:5] <- c(-1,-2) # Three elements to be filled with two elements...
        b
#     If the length does not divide, there is a warning message,
#     but cyclical fill-in is done anyway.
#
#---   
#
#
# * ENTERING DATA IN VECTORS:
#
#   - Manual entry of a vector:
        x <- c(-1,2,5)
#    
#   - Equispaced sequences of numbers:
        3:10
        10:3
        seq(3, 10)
        seq(3, 10, by=1/3)   # Third argument is names "by"
        seq(3, 10, len=8)
#
#   - Repetitions:
        rep(3, 10)
        rep(1:3, 5)
#     Here is something more complex that "rep" can also do:
        rep(c(1,2,3,4), c(2,3,2,3))
        rep(1:3, rep(2,3))
#    
#   - Logical values:
        rep(T,5)
        ((1:10) > 5)
        (1:10)[(1:10) > 5]
#    
#   - Random numbers:
        x <- runif(5)    # Five uniform random numbers in [0,1]; see below.
        y <- rnorm(5)    # Five standard normal random numbers; see below.
#    
#---
#
# * AUTOMATIC VECTOR EXTENSION:
#
#     Array-bound errors for vectors do NOT exist for positive indexes!!!   
#     Vectors are shown as NA if indexed out of bounds, and
#     automatically extended if assigned out of bounds.
        x <- runif(5)
        x[6]           # NA, not an error message.
        x[10] <- 9.99  # Not an error!  Element 10 now exists.
        x              # So do elements 6,7,8,9, which are filled in with NA.
        length(x)        # Assignment can extend the length.
#     However, negative indexes (used for exclusion) can be out of bounds:
        x[-11]           # Out of bounds.
        x[-9]            # Ok, because of fill-in after assigning element 10.
#     Automatic vector extension makes vectors very different from
#     matrices and arrays.
#
#---
#
# * NAMED VECTOR ELEMENTS:
#
#   - Vector elements can be named:
        x <- c(first=1,second=7,third=5,fourth=3)
        x
#   - Equivalently, naming elements can be performed in a separate step
#     by assigning the "names()" attribute:
        x <- c(1,7,5,3)
        names(x) <- c("first","second","third","fourth") 
        x
        names(x)
#   - Element names can be used for indexing/subsetting:
        x["second"]
        x[c("second","fourth")]
        nm <- c("second","third","second","third");  x[nm]
#   - Named assignment/extension is possible:
        x[c("fourth","fifth")] <- c(10,11)
#     Note: "fourth" existed and is re-assigned;
#           "fifth" did not exist and is an extension of "x".
#   - If names are not unique, the first matching name is selected:
        c(a=1,b=2,a=3)["a"]
#
#---
#
# * NAMED VECTOR ELEMENTS AS ASSOCIATIVE ARRAYS:
#     This is a limited capability involving lookup by strings only.
#     (Python has lookup by more general objects.)
#     Assume you want to look up, say, salaries of persons given by name.
#     Assume that salaries and names are stored in parallel vectors:
        slry <- c(35000, 100000, 12000)
        nm   <- c("John", "Bill", "Jim")
#     You turn "slry" into an associative array by giving its elements names:
        names(slry) <- nm
#     Salaries are now "associated" with names for lookup by name,
#     the names are the "keys", the salaries the "values".
#     For example, Bill's salary is: 
        slry["Bill"]          # Bill is the key, slry["Bill"] the value.
#     NOTE: If one wants to use numbers as keys, they have to be
#     converted to strings first.  The conversion happens automatically
#     through coercion, as in
        names(slry) <- c(10,20,30)
#           The keys are now the strings "10", "20", "30":
        slry["20"]    
#
#---
#
# * RANKING, SORTING, REVERSING:
        x=c(1,9,5,3,7)
        rank(x)
        sort(x)
        rev(x)
#     Here is one of the more important functions: 
        order(x)
        sort(x)
        x[order(x)]   # Same!
#     This is how you perform parallel sorting:
        y <- runif(length(x))   # Just another vector of the same length.
        x; y                    # Unordered parallel vectors
        ord <- order(x)
        x[ord]; y[ord]  # Sorts both "x" and "y" in ascending order of "x".
#
#
#---
#
# * SIMPLE STATISTICS:
        length(x)
        sum(x)
        mean(x)
        var(x)
        sqrt(var(x))
        min(x)
        max(x)
        range(x)
        median(x)
#    
#---
#
# * SIMPLE FUNCTIONS/TRANSFORMATIONS:
#     Most functions will accept vectors or matrices or arrays
#     and apply elementwise!!
        x <- runif(50)*10
        round(x)
        abs(x)    
        sqrt(x)
        log(x^2)
        exp(1)
        cos(pi)    # "pi" is predefined; the number e=exp(1) is not.
        acos(0.5)
#
#
################