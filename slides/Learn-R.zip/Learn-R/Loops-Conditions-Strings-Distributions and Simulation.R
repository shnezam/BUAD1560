################################################################
#
# Flow control: loops, conditionals
#
#   - if-conditional:
        if(length(m) > 10) { print("m is greater than 10") }
#     With "else" clause:
        if(length(m) > 10) {
          print("m > 10")
        } else { 
          print("m <= 10")
        } 

#   - The vectorized "ifelse()" function:
#     Not a flow control construct, but often replaces a combination of
#     for-loop and if-else statements.
        ifelse(c(T,F,T), c(1,2,3), c(-1,-2,-3))
#     The function runs down the three arguments in parallel,
#     checks each element in the first argument,
#     if true,  picks the corresponding element in the second argument,
#     if false, picks the corresponding element in the third argument,
#     returns a vector/matrix/array of the size of the first argument.
#     If the second or third argument are not conforming,
#     they are cyclically repeated, as in this implementation of
#     10 Bernoulli trials:
        ifelse(runif(10) > 0.5, 1, 0)

#   - for-loop: runs over the elements of a vector.
        for(i in c(10,100,1000)) { j <- 2*i; print(j); }
#     Braces are optional if there is only one statement in the loop.

#   - repeat-loop: needs a "break" for termination.
        repeat{ print("Trying..."); rnum <- runif(1);
                if(rnum > 0.9) { print(c("Found one:",rnum)); break } }

#   - while-loop:
        while(runif(1) < 0.99) { print("Not yet...") }; print("Finally...")
#
################################################################
#
# * String manipulation:
#
#   R has a number of functions that make the use of other scripting
#   languages such as awk, perl, python less and less necessary for
#   pattern matching problems.  There are functions for searching
#   and substituting text patterns expressed as so-called
#   "regular expressions".  Here is a collection:
#
#      paste(..., sep = " ", collapse = NULL)
#      substr(x, start, stop)
#      substring(text, first, last = 1000000)
#      substr(x, start, stop) <- value
#      substring(text, first, last = 1000000) <- value
#      strsplit(x, split, extended = TRUE)
#      nchar(x)
#      chartr(old, new, x)
#      tolower(x)
#      toupper(x)
#      casefold(x, upper = FALSE)
#      match(x, table, nomatch = NA, incomparables = FALSE)
#      x %in% table
#      pmatch(x, table, nomatch = NA, duplicates.ok = FALSE)
#      charmatch(x, table, nomatch = NA)
#      grep(pattern, x, ignore.case=FALSE, extended=TRUE, value=FALSE)
#      sub(pattern, replacement, x,
#              ignore.case=FALSE, extended=TRUE)
#      gsub(pattern, replacement, x,
#              ignore.case=FALSE, extended=TRUE)
#      regexpr(pattern, text,  extended=TRUE)
#
#  String dimensions when plotting:
#      strwidth(s, units = "user", cex = NULL)
#      strheight(s, units = "user", cex = NULL)
#
#  Example:
     dict <- scan("dict.dat",w="")
     sel <- grep("source", dict)   # All words containing "source".
     dict[sel]
#
################################################################
#
# * Distributions: Pseudo-random numbers, quantiles, cdfs, densities
#
#     The following continuous distributions come with the standard
#     version of R, each with
#     * a random number generator,
#     * a quantile function,
#     * a cdf function, and
#     * a density fct.

#   - Uniform:
#       runif(n, min = 0, max = 1) 
#       qunif(p, min = 0, max = 1, lower.tail = TRUE, log.p = FALSE) 
#       punif(q, min = 0, max = 1, lower.tail = TRUE, log.p = FALSE) 
#       dunif(x, min = 0, max = 1, log = FALSE) 
#
#   - Normal:
#       rnorm(n, mean = 0, sd = 1) 
#       qnorm(p, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE) 
#       pnorm(q, mean = 0, sd = 1, lower.tail = TRUE, log.p = FALSE) 
#       dnorm(x, mean = 0, sd = 1, log = FALSE) 
#                  
#   - Student's t:
#       rt(n, df)         
#       qt(p, df, lower.tail = TRUE, log.p = FALSE)
#       pt(q, df, ncp, lower.tail = TRUE, log.p = FALSE)
#       dt(x, df, log = FALSE)
#
#   - F:
#       rf(n, df1, df2)
#       qf(p, df1, df2, lower.tail = TRUE, log.p = FALSE) 
#       pf(q, df1, df2, ncp = 0, lower.tail = TRUE, log.p = FALSE) 
#       df(x, df1, df2, log = FALSE) 
#                  
#   - Chi-square:
#       rchisq(n,df,ncp=0)
#       qchisq(p, df, ncp = 0, lower.tail = TRUE, log.p = FALSE) 
#       pchisq(q, df, ncp = 0, lower.tail = TRUE, log.p = FALSE) 
#       dchisq(x, df, ncp = 0, log = FALSE) 
#                  
#   - Exponential:
#       rexp(n, rate = 1)
#       qexp(p, rate = 1, lower.tail = TRUE, log.p = FALSE) 
#       pexp(q, rate = 1, lower.tail = TRUE, log.p = FALSE) 
#       dexp(x, rate = 1, log = FALSE) 
#                  
#   - Cauchy:
#       rcauchy(n, location = 0, scale = 1) 
#       qcauchy(p, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE)
#       pcauchy(q, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE)
#       dcauchy(x, location = 0, scale = 1, log = FALSE) 
#                  
#   - Beta:
#       rbeta(n,shape1,shape2)
#       qbeta(p, shape1, shape2, lower.tail = TRUE, log.p = FALSE) 
#       pbeta(q, shape1, shape2, ncp = 0, lower.tail = TRUE, log.p = FALSE) 
#       dbeta(x, shape1, shape2, ncp = 0, log = FALSE) 
#                  
#   - Gamma:
#       rgamma(n,shape,rate=1,scale=1/rate)
#       qgamma(p, shape, rate = 1, scale = 1/rate, lower.tail = TRUE, 
#       pgamma(q, shape, rate = 1, scale = 1/rate, lower.tail = TRUE, 
#       dgamma(x, shape, rate = 1, scale = 1/rate, log = FALSE) 
#                  
#   Some uses:
#     - Random number generators are used, for example, 
#       . in simulations, as when evaluating the efficiency
#           of statistical methods;
#       . in Bootstrap inference for frequentist statistics;
#       . in Bayesian computing to simulate posterior distributions.
#     - The quantile functions are used
#       . to find critical values in statistical tests;
#       . in q-q-plots to check empirical against theoretical distributions
#         (see below).
#     - The cdf functions are used for calculating p-values in 
#         statistical tests.
#     - The normal density is sometimes used as a "kernel" in 
#         smoothing methods.
#
# * Simulating discrete distributions:
#     - Bernoulli trials, as we have seen earlier:
          ifelse(runif(10)<0.6, 1, 0)                      # P[X=1]=0.6
#     - Binomials:
#       . one binomial:
            sum(ifelse(runif(10)<0.6, 1, 0))                 
#       . 10 binomials:
            for(i in 1:10) print(sum(ifelse(runif(10)<0.6, 1, 0)))
#         5 binomials.
            apply(matrix(ifelse(runif(50)<0.6, 1, 0), 5, 10), 1, sum)
#     - Poisson...

# * Important note on seeding random number generators:
#     The "seed" stores the state of the pseudo-random number generator.
        .Random.seed
        runif(1)
        .Random.seed                      # The seed has changed.
        Random.seed.store <- .Random.seed # Store the seed.
        runif(1)                          # (*) Remember this random number.
        runif(10)                         # Now push the generator 10 times.
        .Random.seed <- Random.seed.store # Force it back to recreate (*)
        runif(1)
#     Indeed, this is the same random number as in (*).
#     Storing the seed is important for simulations that must be
#     reproduceable, for example, when putting simulation results
#     in a publication.

#  Repeat the same random number
        runif(1)
        runif(1)
        set.seed(101)
        runif(1)
        set.seed(101)
        runif(1)
#
# * Sampling:
#     Often one doesn't need random numbers but random selections,
#     i.e., samples.  This is done by "sample()", which can do both
#     with and without replacement.
#     Arguments:  sample(x, size, replace = FALSE, prob = NULL) 
#     Recall you can learn this by simply saying
        sample
#     Examples:
        sample(1:10, 5)                  # Samples w/o replacement (default).
        sample(1:10, 5, replace=T)       # Samples with replacement 
        sample(10)                       # Random permutation of 1:10.
#     The function can also be applied to non-numeric data:
        sample(letters)                  # A permutation of letters.
        sample(letters, 10)              # 10 distinct random letters.
        sample(letters, 10, repl=T)      # 10 i.i.d. samples of letters.
        sample(letters, 100)             # Error!  Sampling w/o replacement.
        sample(letters, 100, repl=T)     # Fine!  Sampling with replacement.
#
#     "sample()" is used to implement modern resampling methods such as
#     the bootstrap and permutation tests (see below).
#
################################################################