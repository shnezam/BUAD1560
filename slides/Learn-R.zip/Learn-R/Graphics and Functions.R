################################################################
#
# * Graphics: "Data Visualization"
#
# Some literature:
#   - William S. Cleveland: "Visualizing Data" (1993)
#   - William S. Cleveland: "The Elements of Graphing Data" (1994)
#   - J.M.Chambers, W.S. Cleveland, B. Kleiner, P.A.Tukey:
#       "Graphical Methods for Data Analysis" (1983)
#   - Edward Tufte: "The Visual Display of Quantitative Information"
#   - Michael Friendly's web site at York Univ:
#       http://www.math.yorku.ca/SCS/Gallery/    

# Some artificial data:
    x <- runif(100)
    y <- x^2
    plot(x,y)
# Why are points so random?  Because the x values are random.
# Redo the same with evenly spaced x values:
    x <- seq(0,1,len=100);    y <- x^2;    plot(x,y)
#    
# Too boring, let's add some error...
    err <- rnorm(100,0,.05)    # Mean=0, stdev=0.2
    y <- x^2 + err
    plot(x,y)
    plot(x, x^2+err)          # Same, but the y-label changes.
    
# "Plot()" has many named arguments.  For example,
# if we're unhappy with labels and scales, they can be set:
    plot(x, y,
         xlab="Hor Var",  ylab="Vert Var",        # axis labels
         xlim=c(-0.2,1.2),  ylim=c(-0.6,1.4),     # axis limits
         main="My First Fancy R Plot")            # title
#
# Matrix Plot
        plot(USArrests)
# Histogram
        hist(USArrests$Murder)
# Box-Plot
        boxplot(USArrests)
		help(USArrests)
# Note that UrbanPop is a proportion, so it is different from the rest.
        boxplot(USArrests[,-3])
# QQ-Plot
        qqnorm(USArrests$UrbanPop)
#
# Another Example: Australian Institute of Sport
#
		ais <- read.table("ais.dat", header=T)
# Matrix Plot
		plot(ais)
# Histogram
		hist(ais$ssf)
# Box-Plot
		boxplot(ais)
# QQ-Plot
		qqnorm(ais$ssf)		
#
#################################################################
#
# * Writing your own functions
#
# The general syntax for defining a function is
#
# > name <- function(arg1, arg2, ...) expr1
#
# The function is called by using
# 
# > name(...)
# Simple Example
		add <- function(a,b) a+b
		add(5,6)
#
# An Approximate Miles to Kilometers Conversion
		miles.to.km <- function(miles)miles*8/5
		miles.to.km(97)  # Approximate distance to Houston
#
# Another example: cubic plot a(x^3)+b(x^2)+c(x)+d
	poly.plot <- function(a=0,b=0,c=0,d=0) {
		x <- (-10:10);
		plot(x,a*x^3+b*x^2+c*x+d,type="b");
	}
	poly.plot(a=1,b=0,c=0,d=0);
	poly.plot(0,1,0,0);
	poly.plot(d=5);
	poly.plot(0,-1);
#
# Monty Hall Problem
# http://en.wikipedia.org/wiki/Monty_Hall_problem
# A weak Solution
#
	monty.hall.1 <- function(nreps=10000) {
      #Possibilities, Probabilities and Strategies
      doors <- c("goat.1","goat.2","car");
      prob <- c(1/3,1/3,1/3)
	  switch <- numeric(); 	  not.switch <- numeric();
	
	  #Run Simulation
	  for (i in 1:nreps) {
		choice <- sample(doors,1,prob=prob)
		if (choice=="goat.1") {
			not.switch <- c(not.switch,0)
			switch <- c(switch,1)
		}
		if (choice=="goat.2") {
			not.switch <- c(not.switch,0)
			switch <- c(switch,1)
		}
		if (choice=="car") {
			not.switch <- c(not.switch,1)
			switch <- c(switch,0)
		}
	  }

	 return(list(switch=switch,not.switch=not.switch))
	}
#
	simul <- monty.hall.1();
	simul
#
# Probability of winning under SWITCH strategy.
	mean(simul$switch)
# Probability of winning under DO NOT SWITCH strategy.
	mean(simul$not.switch)
#
# Make sure to use the R features to write an optimized code
# Better Solution
#
	monty.hall.2 <- function(nreps=10000) {
      #Possibilities, Probabilities and Choices
      doors <- c("goat.1","goat.2","car")
      prob <- c(1/3,1/3,1/3)
      choices <- sample(doors,nreps,replace=T,prob)

      #Defigning two different arrays for different strategies.
      switch <- numeric(nreps)
      not.switch <- numeric(nreps)

      #Decisions
	  not.switch[choices=="car"] <- 1 
	  switch[choices!="car"] <- 1

     return(list(switch=switch,not.switch=not.switch))
	}
#
	simul <- monty.hall.2();
	mean(simul$switch)
	mean(simul$not.switch)
#
# To compare the performances
#
	system.time(monty.hall.1(100000))
	system.time(monty.hall.2(1000000))
#
##################################################################