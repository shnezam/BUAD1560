################ 
#
# * MATRICES:
#     Matrices in R are vectors with additional "meta-information"
#     to structure them in a rectangular form.  
#     The elements of the vector fill the matrix column by column.
#     ==> COLUMN MAJOR ORDER, as in Fortran, but unlike in C.
#     Reformatting as a matrix is achieved by giving the vector
#     a dimension attribute consisting of the numbers of rows and cols.
#
#   - Reformatting vectors as matrices by filling successive cols or rows:
        matrix(1:12, ncol=4)             # Column major (default)
        matrix(1:12, nrow=3)             # Same
        matrix(1:12, ncol=4, byrow=T)    # Row major, forced with "byrow".
        matrix(1:12, nrow=3, byrow=T)    # Same
#   Available datasets in R:
		data()
#	Read a dataset
		m <- USArrests
#     Later we will see a function for reading a table from a file.
#     tabular data ('read.table()').
#
#   - The dimension attribute: it is the sole difference between
#     a vector and a matrix.  It can be queried:
        dim(m)                # Vector of length 2 with the two dimensions.
        dim(m)[1];  dim(m)[2] # Each dimension separately.
        nrow(m);  ncol(m)     # Same.
#     Think of an attribute of an object as a tag.
#     Vectors can be turned into matrices by assigning the
#     dimension attribute:
        m <- 1:12           # Just a vector.
        dim(m) <- c(3,4)    # Now a matrix.
        m
        dim(m) <- NULL      # Stripping to a vector.
        m
#     The matrix property can be queried as follows:
        is.matrix(matrix(1:12,3));   is.matrix(1:12)

#   - Indexing/subselecting rows and columns:        (differs from C!)
        m[1,4]                    # Element in row 1, column 4.
        m[1:3,]                   # First 3 rows.
        m[,3:4]                   # Last 2 columns.
        m[1:3,3:4]                # First 3 rows, last 2 columns.
        m[c(1,2,1,2),]            # Repeat rows 1 and 2.
        m[,c(1,2,1,2)]            # Repeat columns 1 and 2.
        m[c(1,2,1,2),c(1,2,1,2)]  # Repeat left-upper 2x2 matrix 4 times.
        m[-1,]                    # Select all but the first row.
        m[,-c(2,4)]               # Select all but columns 2 and 4.
#     ATTENTION: Row and column selection generates vectors
#                who do no longer know that they were rows or cols.
#                R has no concept of col-vectors and row-vectors.
#                Vector is vector, period.
#
#   - Index/subsetting can be used for assignment:
        m[1,2]     <- 0
        m[1,]      <- rep(0,4)
        m[,1]      <- rep(0,3)
        m[1,c(F,F,T,T)]   <- c(7,10)
#
#   - Associative array feature for matrices:
        rownames(m) <- c("x","y","z")       # like 'names(vec)'
        colnames(m) <- c("a","b","c","d")
        m["x","d"]           # number
        m["x",]              # vector
        m[,"c"]              # vector
        m[c("x","z"),c("c","a")]   # submatrix
        m[c("x","z","x","y"),c("c","a","a")] # col-row-rearrangement
#
#   - Column and row binding:
#     Two functions that permit collecting cols and rows to form matrices.
        x <- runif(5)                    # Play data.
        cbind(1:5, x, x, rep(10,5))      # Column binding.
        rbind(1:5, x)                    # Row binding.
#     (Vectors are NOT thought of as columns or rows on their own;
#      they take on these roles inside the "cbind" and "rbind" functions.)
#     Both functions accept an arbitrary number of conforming arguments.
#     You can also bind whole matrices:
        cbind(rbind(1:3,11:13,21:23), cbind(1001:1003,2001:2003))
#     A more friendly way of writing the same is:
        m1 <- rbind(1:3,11:13,21:23)        # 3x3
        m2 <- cbind(1001:1003,2001:2003)    # 3x2
        cbind(m1, m2)                       # 3x5
#     Conforming for 'cbind()' means the arguments have equal number
#     of rows, for 'rbind()' it means equal number of columns.  
#     If vector arguments are not conforming, R extends them cyclically
#     or clips them but may give you a warning if the shorter arguments
#     are not of fractional length of the longest argument:
        cbind(1:3,0)        # second arg has size 1, = fraction of 3
        cbind(1:6,1:3)      # size 3 is a fraction of size 6
        cbind(1:3,1:2)      # size 2 is not a fraction of size 3 => warning
        cbind(1:3,matrix(11:14,2)) # clipping: the second arg dictates nrow
#     Don't rely on cyclic extension except for the simplest cases
#     such as repeating constants.
#
# --- 

#   - Operating on rows of matrices:
        apply(m, 1, min)   # Return a vector with minima of the rows.
#                   ^^^ the "min()" function, applied to the 1st dimension.
#
#   - Operating on columns of matrices:
        apply(m, 2, mean)  # Return a vector with the means of the columns.
#                   ^^^^ the "mean()" function, applied to the 2nd dim.
#
#     'apply()' can also be used with functions that return vectors, 
#     such as 'range()' and 'sort()':
        apply(m, 2, range)
#     There are complications with "apply(m, 1, range)":
#     the result is 2xnrow(m), not nrow(m)x2, as one would expect.
#     This requires transposition, 't()', to get the expected matrix:
        t(apply(m, 1, range))
#
#   - REMINDER: Automatic coercion of rx1 and 1xc matrices to vectors,
#               i.e., loss of the dim attribute
          matrix(1:12,3)[1,];  matrix(1:12,3)[,2]
#       If you do need rx1 or 1xc matrices, you need to glue the
#       dim attribute on by force:
          x <- matrix(1:9,3)[,2]
          x
          dim(x) <- c(3,1);  # 3x1 matrix, or column vector
          x  
          dim(x) <- c(1,3);  # 1x3 matrix, or row vector
          x
# * ARRAYS: the generalization of matrices to more than 2 indexes
#
      a <- array(1:24, c(2,3,4))
      a[1,2,1]
      a[,2:3,c(1,4)]
#
################
